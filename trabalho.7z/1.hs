import qualified Data.ByteString.Char8 as C
import Control.DeepSeq
import Control.Exception

lerArquivo :: String -> IO ()
lerArquivo arquivo = do
	arquivo <- readFile arquivo
	let lista = lines arquivo
	let string = unlines lista
	appendFile "pao.txt" string

adicionarCliente :: IO ()
adicionarCliente = do
	clientesFile <- readFile "cliente.db"
	let clientes = lines clientesFile
	let codigo = novaId clientes
	print ("Digite o nome")
	nome <- getLine
	print ("Digite a cidade")
	cidade <- getLine
	print ("Digite a idade")
	idade <- getLine
	print ("Digite o sexo")
	sexo <- getLine

	evaluate (force clientesFile)
	appendFile "cliente.db" (""++codigo++",\""++nome++"\",\""++cidade++"\","++idade++",'"++sexo++"'\n")

adicionarProduto :: IO ()
adicionarProduto = do
	arquivo <- readFile "produto.db"
	let produtos = lines arquivo
	let codigo = novaId produtos
	print (codigo)
	print ("Digite o nome")
	nome <- getLine
	print ("Digite a quantidade em estoque")
	quantidade <- getLine
	print ("Digite o preco unitario ou por Kilo")
	preco <- getLine

	evaluate (force arquivo)
	appendFile "produto.db" (""++codigo++",\""++nome++"\","++quantidade++","++preco++"\n")

novaId :: [String] -> String
novaId (a:[]) = show ((read (pegarAtributo (quebrarString ',' a) 0)::Int)+1)::String
novaId (a:b) = novaId b

pegarAtributo :: [String] -> Int -> String
pegarAtributo (a:_) 0 = a
pegarAtributo (a:b) posicao = pegarAtributo b (posicao - 1)

quebrarString :: Char -> String -> [String]
quebrarString _ "" = []
quebrarString c s = let (l, s') = break (== c) s
						in l : case s' of
							[] -> []
							(_:s'') -> quebrarString c s''

excluirRegistro :: [String] -> String -> [String]
excluirRegistro [] _ = []
excluirRegistro (a:b) excluir | (pegarAtributo (quebrarString ',' a) 0 == excluir) = excluirRegistro b excluir
							  | otherwise = a:excluirRegistro b excluir

buscarRegistro :: [String] -> Int -> String -> [String]
buscarRegistro [] _ _ = []
buscarRegistro (a:b) posicao comparador | (pegarAtributo (quebrarString ',' a) posicao == comparador) = quebrarString ',' a
										| otherwise = buscarRegistro b posicao comparador

alterarRegistro :: String -> Int -> IO ()
alterarRegistro arquivo id | (pegarAtributo)

alterarCliente :: IO ()
alterarCliente = do
	print ("Digite o id do cliente a ser alterado")
	id <- getLine
	arquivo <- readFile "cliente.db"
	let lista = lines arquivo
	let novaLista = excluirRegistro lista id
	evaluate (force arquivo)
	writeFile "cliente.db" (unlines novaLista)

	print ("Digite um novo nome")
	nome <- getLine
	print ("Digite um novo cidade")
	cidade <- getLine
	print ("Digite um novo idade")
	idade <- getLine
	print ("Digite um novo sexo")
	sexo <- getLine

	appendFile "cliente.db" (""++id++",\""++nome++"\",\""++cidade++"\","++idade++",'"++sexo++"'\n")


main = do
	print ("Digite a acao desejada.")
	print ("1- Adicionar registro")
	print ("2- Alterar registro")
	print ("3- Excluir registro")
	escolhaString <- getLine
	let escolha = (read escolhaString::Int)
	if (escolha == 1) then do
		print ("Escolha o registo a que deseja adicionar")
		print ("1- Cliente")
		print ("2- Produto")
		adicionarString <- getLine
		let adicionar = (read adicionarString::Int)
		if (adicionar == 1) then
			adicionarCliente
		else
			adicionarProduto
	else
		if (escolha == 2) then do
			print ("Escolha o registro que deseja alterar")
			print ("1- Cliente")
			alterarString <- getLine
			print ("Escolha o id que deseja alterar")
			id <- getLine
			let alterar = (read alterarString::Int)
			if (alterar == 1) then
				alterarRegistro "cliente.db" id
			else
				print ("pew")
		else
			print ("pewpew")
	lerArquivo "cliente.db"